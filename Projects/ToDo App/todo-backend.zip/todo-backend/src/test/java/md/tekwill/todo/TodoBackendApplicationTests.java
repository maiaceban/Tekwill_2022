package md.tekwill.todo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
